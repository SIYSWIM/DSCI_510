import sys


def main():
    # return error if no operator mentioned
    if len(sys.argv) < 2:
        sys.stderr.write("Error: Missing operator\n")
    # Exit the script with an error status
        sys.exit(1)
    
    # Get the command line argument
    operator = sys.argv[1]

## type of output depends on type of input

    # add function
    operator = operator.lower()
    if operator == 'add':
        if len(sys.argv) < 3:
            result = 0
            print(f'Result will be {result} (empty sum)')
        else:
            result = 0
            for arg in sys.argv[2:]:
                if '.' in arg:
                    arg = float(arg)
                    result += arg
                else:
                    arg = int(arg)
                    result += arg
            print(f'Result will be {result}')
        
    # subtract function
    operator = operator.lower()
    if operator == 'subtract':
        if len(sys.argv) < 3:
            # print missing nums if no nums followed
            print('empty value for subtraction')
        else:       
            if '.' in sys.argv[2]:
                result = float(sys.argv[2])
            else:
                result = int(sys.argv[2])

            for arg in sys.argv[3:]:
                if '.' in arg:
                    arg = float(arg)
                    result -= arg
                else:
                    arg = int(arg)
                    result -= arg
            print(f'Result will be {result}')
    
## output will all be float no matter what are the input

    # multiply function
    operator = operator.lower()
    if operator == 'multiply':
        if len(sys.argv) < 3:
            # print missing nums if no nums followed
            print('empty value for multiplication')
        else:
            result = float(sys.argv[2])
            for arg in sys.argv[3:]:
                result *= float(arg)
            print(f'Result will be {result}')
    
    # divide function
    operator = operator.lower()
    if operator == 'divide':
        if len(sys.argv) < 3:
            # print missing nums if no nums followed
            print('empty value for Division')
        else:
            result = float(sys.argv[2])
            for arg in sys.argv[3:]:
                result /= float(arg)
            print(f'Result will be {result}')

if __name__ == '__main__':
    main()